package com.bonsamp.mobile.model

data class ServerEntry(
    val name: String,
    val ip: String,
    val port: Int,
    val players: Int,
    val maxPlayers: Int,
    val ping: Int,
    val gamemode: String
)
